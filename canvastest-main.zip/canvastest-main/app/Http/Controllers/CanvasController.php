<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use Illuminate\Http\Client\Response;
use Illuminate\Http\Request;
use App\Models\Course;

class CanvasController extends Controller
{
    public function index() {
        return view('welcome');
    }

    public function getCourses() {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . \Config::get('values.api_key')
        ])->get(\Config::get('values.default_canvas_url') . 'courses?enrollment_type=teacher');
        // \Log::info(json_decode($response->body())[0]->name);
        $courses = json_decode($response->body());
        //foreach ($courses as $course) {
            //\Log::info("name: " . $course->name . ", ID: " . $course->id);
        //}
        //\Log::info("");
        return view('/example', ['courses'=>$courses]);
    }

    public function getStudents(Request $request) {
        $id = $request->id;
        $courseName = $request->name;
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . \Config::get('values.api_key')
        ])->get(\Config::get('values.default_canvas_url') . 'courses/' . $id . '/users?enrollment_type[]=student');
        // \Log::info(json_decode($response->body()));
        $students = json_decode($response->body());
        //foreach ($students as $student) {
            //\Log::info($student->name);
        //}
        return view('/students', ['students'=>$students, 'courseName'=>$courseName]);
       
    }

    public function makeSurvey(Request $request) {
        $id = $request->id;
        $date = new \DateTime('now', new \DateTimeZone(date_default_timezone_get()));
        
        //\Log::info($id);
        //$surveyName = 'Aggregation Data Survey';
        $surveyName = "{$date->format('Y-m-d\TH:i:s\Z')}";
        $due = $this->getDateIn7Days();

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . \Config::get('values.api_key')
        ])->asForm()->post(\Config::get('values.default_canvas_url') . 'courses/' . $id . '/quizzes', [
            'quiz[title]' => $surveyName,
            'quiz[description]' => 'A survey that will be used to collect data for group projects',
            'quiz[quiz_type]' => 'graded_survey',
            'quiz[hide_results]' => "always",
            'quiz[due_at]' => $due,
            'quiz[lock_at]' => $due,
            'quiz[published]' => false
        ]);
        $quiz = json_decode($response->body());
        \Log::info(json_encode($quiz));
        $this->createDataQuestions($quiz, $id);
        return redirect('/');
    }

    private function createDataQuestions($quiz, $courseId){
        $accessToken = \Config::get('values.api_key');
        $canvasInstance = \Config::get('values.default_canvas_url');
        //\Log::info("{$canvasInstance}courses/{$courseId}/quizzes/{$quiz->id}/questions");

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . \Config::get('values.api_key')
        ])->asForm()->post(\Config::get('values.default_canvas_url') . 'courses/' . $courseId . '/quizzes' . '/' . $quiz->id . '/questions', [
            'question' => [
                'question_name' => 'Gender',
                'question_text' => 'Gender',
                'question_type' => 'multiple_choice_question',
                'points_possible' => 1,
                'answers' => [
                    [
                        'text' => 'Male',
                        'weight' => 100
                    ],
                    [
                        'text' => 'Female',
                        'weight' => 0
                    ],
                    [
                        'text' => 'Other',
                        'weight' => 0
                    ]
                ]
            ]
        ]);

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . \Config::get('values.api_key')
        ])->asForm()->post(\Config::get('values.default_canvas_url') . 'courses/' . $courseId . '/quizzes' . '/' . $quiz->id . '/questions', [
            'question' => [
                'question_name' => 'Race',
                'question_text' => 'Race',
                'question_type' => 'multiple_choice_question',
                'points_possible' => 1,
                'answers' => [
                    [
                        'text' => 'White',
                        'weight' => 100
                    ],
                    [
                        'text' => 'African American',
                        'weight' => 0
                    ],
                    [
                        'text' => 'Asian',
                        'weight' => 0
                    ],
                    [
                        'text' => 'Other',
                        'weight' => 0
                    ]
                ]
            ]
        ]);

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . \Config::get('values.api_key')
        ])->asForm()->post(\Config::get('values.default_canvas_url') . 'courses/' . $courseId . '/quizzes' . '/' . $quiz->id . '/questions', [
            'question' => [
                'question_name' => 'Major',
                'question_text' => 'Major',
                'question_type' => 'multiple_choice_question',
                'points_possible' => 1,
                'answers' => [
                    [
                        'text' => 'Computer Science',
                        'weight' => 100
                    ],
                    [
                        'text' => 'Other',
                        'weight' => 0
                    ]
                ]
            ]
        ]);

        \Log::info($response->body());
    }

    private function getDateIn7Days() {
        $date = new \DateTime('now', new \DateTimeZone(date_default_timezone_get()));
        $date->modify('+8 days');
        $date->setTime(3, 59, 0);
        $date->setTimezone(new \DateTimeZone('UTC'));
        return $date->format('Y-m-d\TH:i:s\Z');
    }

}