<?php

use Illuminate\Support\Facades\Route;
USE App\Http\Controllers\CanvasController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [CanvasController::class, 'index'])->name('index');

Route::post('/getcourses', [CanvasController::class, 'getCourses'])->name('getCourses');

Route::post('/seestudents/{id}/{name}', [CanvasController::class, 'getStudents'])->name('getStudents');

Route::post('/makesurvey/{id}', [CanvasController::class, 'makeSurvey'])->name('makeSurvey');
