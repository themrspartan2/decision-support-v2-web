<?php

    return [
        'default_canvas_url' => env('DEFAULT_CANVAS_API_URL', 'https://canvas.instructure.com/api/v1/'),
        'api_key' => env('CANVAS_KEY', '1053~MErX4OQrbnxzDvYGDQvwWV96eGdwztuQKi6jCehVTAfbLJKwtlM83Gs1jpcJvy5N')
    ];