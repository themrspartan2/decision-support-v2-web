import java.util.ArrayList;

// Could implelemt something like Collection<Student>
public class Group {
	
	// ========================================== Properties
	
	private ArrayList<Student> students;
	private int limit;
	private int currSize;
	
	// ========================================== Constructor
	
	public Group(int limit) {
		this.students = new ArrayList<Student>();
		this.limit = limit;
		this.currSize = 0;
	}
	
	// ========================================== Methods
	
	/**
	 * Adds a student to the group
	 * @param s The student to add to the group
	 * @throws IllegalArgumentException if there is not space in the group
	 */
	public void addStudent(Student s) {
		if (currSize < limit) {
			students.add(s);
			currSize++;
		} else {
			throw new IllegalArgumentException("The group is full and cannot accept new students");
		}
	}
	
	/**
	 * Checks if the group is full
	 * @return true if the group is full; false otherwise
	 */
	public boolean isFull() {
		return this.currSize == this.limit;
	}
	
	/**
	 * Checks if the group is empty
	 * @return true if the group is empty; false otherwise
	 */
	public boolean isEmpty() {
		return this.currSize == 0;
	}
	
	public double getGradeSum() {
		double sum = 0;
		for (Student s : students) {
			sum += s.getGrade();
		}
		return sum;
	}
	

	@Override
	public String toString() {
		String ret = "";
		for (Student s : this.students) {
			ret += " | " + s.toString();
		}
		return "[" + ret.substring(3) + "]";
	}
	
	/**
	 * Returns a string representation of the group with students' minorityStatus
	 * @return A string representation of the group
	 */
	public String toStringMino() {
		String ret = "";
		for (Student s : this.students) {
			ret += " | " + s.toStringMino();
		}
		return "[" + ret.substring(3) + "]";
	}
	
	/**
	 * Returns a string representation of the group with students' grade
	 * @return A string representation of the group
	 */
	public String toStringGrade() {
		String ret = "";
		for (Student s : this.students) {
			ret += " | " + s.toStringGrade();
		}
		return "[" + ret.substring(3) + "]";
	}
	
	// ========================================== Getters
	
	public int getLimit() {
		return limit;
	}

	public int getCurrSize() {
		return currSize;
	}
	
	public Student getStudent(int index) {
		return students.get(index);
	}
	
	public void replaceStudent(int index, Student s) {
		this.students.set(index, s);
	}
	
	public void emptyGroup() {
		this.students.clear();
		this.currSize = 0;
		
	}
}
