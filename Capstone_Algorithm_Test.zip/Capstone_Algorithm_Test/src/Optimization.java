import java.util.ArrayList;

public class Optimization {
	
	// ========================================== main() method for testing
	
	public static void main(String[] args) {
		
		// Create some sample students and stuff them in a locker
		// Attributes are first, second, and third project choices right now, higher priorities at lower indices
		String[] attr0 = {"a", "c", "d"};
		Student stud0 = new Student("John", true, 100, attr0);
		
		String[] attr1 = {"a", "c", "d"};
		Student stud1 = new Student("Jon", true, 73, attr1);
		
		String[] attr2 = {"c", "a", "b"};
		Student stud2 = new Student("Kevin", false, 97, attr2);
		
		String[] attr3 = {"d", "a", "c"};
		Student stud3 = new Student("Karen", false, 69.96, attr3);
		
		String[] attr4 = {"d", "b", "a"};
		Student stud4 = new Student("Gort", false, 72.1, attr4);
		
		String[] attr5 = {"b", "a", "d"};
		Student stud5 = new Student("Quandale", false, 88.32, attr5);
		
		String[] attr6 = {"c", "b", "d"};
		Student stud6 = new Student("Poggers", false, 88, attr6);
		
		String[] attr7 = {"a", "b", "c"};
		Student stud7 = new Student("Queen", false, 62, attr7);
		
		String[] attr8 = {"c", "b", "a"};
		Student stud8 = new Student("Dababy", true, 83.33, attr8);
		
		String[] attr9 = {"b", "a", "c"};
		Student stud9 = new Student("Office Chair", true, 94.2, attr9);
		
		ArrayList<Student> studList = new ArrayList<Student>();
		
		// 0, 2, 9, 5, 6, 8, 1, 4, 3, 7 is in descending order
		studList.add(stud0);
		studList.add(stud2);
		studList.add(stud9);
		studList.add(stud5);
		studList.add(stud6);
		studList.add(stud8);
		studList.add(stud1);
		studList.add(stud4);
		studList.add(stud3);
		studList.add(stud7);
		
		ArrayList<Student> studList2 = new ArrayList<Student>();
		for (Student s : studList) {
			studList2.add(s);
		}
		
//		studList = shuffleStudList(studList);
		
//		System.out.println(studList.toString());
		
		// Perform group optimization
		Group[] groups = balanceByGroupSize(studList, 4);
		
		// Print group configurations
		System.out.println(balancingSuccess(groups, studList2));
		for (Group group : groups) {
			System.out.println(group.toString());
		}
		System.out.println(balancingSuccess(improveBalancing(groups, studList2, 4), studList2));
		for (Group group : groups) {
			System.out.println(group.toString());
		}
	}
	
	// ======================================================================== Clustering Algorithm
	
	/**
	 * Generates a group configuration through clustering by minority status
	 * The user specifies the number of students allowed in each group
	 * @param studList The list of students
	 * @param groupSize The number of students allowed in each group
	 * @return An array of groups of students
	 */
	private static Group[] clusterByGroupSize(ArrayList<Student> studList, int groupSize) {
		int numOfGroups = (int) Math.ceil(studList.size() / ((double) groupSize));
		return clusterByGroupQty(studList, numOfGroups);
	}
	
	/**
	 * Generates a group configuration through clustering by minority status
	 * The user specifies the number of groups
	 * @param studList The list of students
	 * @param numOfGroups The number of groups
	 * @return An array of groups of students
	 */
	private static Group[] clusterByGroupQty(ArrayList<Student> studList, int numOfGroups) {
		
		int groupLimit = (int) Math.ceil(studList.size() / ((double) numOfGroups));
		
		// Create an empty matrix within which to store students
		Group[] groups = new Group[numOfGroups];
		for (int i = 0; i < numOfGroups; i++) {
			groups[i] = new Group(groupLimit);
		}
		
		// Create the ArrayList of minorities to sort
		ArrayList<Student> unassignedMinorities = createMinorityList(studList);
		
		// Add two minorities to each group if possible
		for (Group group : groups) {
			
			// Break if there is nobody to add
			if (unassignedMinorities.size() == 0) {
				break;
			}
			
			// If there is one person to add, add them to the first group if possible, put them in a group alone otherwise
			if (unassignedMinorities.size() == 1) {
				if (groupLimit == 2) {
					group.addStudent(unassignedMinorities.remove(0));
				} else {
					groups[0].addStudent(unassignedMinorities.remove(0));
				}
			
			// If there are two or more people to add, add two to a new group
			} else {
				group.addStudent(unassignedMinorities.remove(0));
				group.addStudent(unassignedMinorities.remove(0));
			}
		}
		
		// If there are still minorities to add, use them to fill out groups
		while (!unassignedMinorities.isEmpty()) {
			for (Group group : groups) {
				group.addStudent(unassignedMinorities.remove(0));
				if (unassignedMinorities.isEmpty()) {
					break;
				}
			}
		}
		
		// Fill in groups that have zero students
		for (Group group : groups) {
			if ((group.getCurrSize() == 0) && (!group.isFull()) && (!studList.isEmpty())) {
				group.addStudent(studList.remove(0));
			}
		}
		
		// Fill in groups that have one student
		for (Group group : groups) {
			if ((group.getCurrSize() == 1) && (!group.isFull()) && (!studList.isEmpty())) {
				group.addStudent(studList.remove(0));
			}
		}
		
		// Fill in remaining empty slots with non-minority students
		// Works from end to beginning to give students to smaller groups first
		while (!studList.isEmpty()) {
			for (int i = groups.length - 1; i >= 0; i--) {
				if ((!groups[i].isFull()) && (!studList.isEmpty())) {
					groups[i].addStudent(studList.remove(0));
				}
			}
		}
		
		return groups;
	}
	
	/**
	 * Helper method for clustering algorithm
	 * Creates a list of students with minorityStatus == true
	 * @param studList
	 * @return
	 */
	private static ArrayList<Student> createMinorityList(ArrayList<Student> studList) {
		ArrayList<Student> minorityList = new ArrayList<Student>();
		for (Student s : studList) {
			if (s.isMinoStatus()) {
				minorityList.add(s);
			}
		}
		for (Student s : minorityList) {
			studList.remove(s);
		}
		return minorityList;
	}
	
	/**
	 * Returns a rating of the group configuration based on how well it is clustered
	 * 100% is a perfectly clustered group configuration, and 0% is a very poorly clustered group configuration
	 * @param groups The array of groups being tested
	 * @param studList The list of students in the groups
	 * @return A percentage
	 */
	private static double clusteringSuccess(Group[] groups, ArrayList<Student> studList) {
		if (groups[0].getLimit() <= 2) {
			return 100.0;
		}
		for (Group group : groups) {
			if (group.getStudent(0).isMinoStatus() == true) {
				if (group.getStudent(1).isMinoStatus() == false) {
					return 0.0;
				}
			}
		}
		return 100.0;
	}
	
	// ======================================================================== Balancing Algorithm
	
	/**
	 * Generates a group configuration through balancing by grade
	 * The user specifies the number students in each group
	 * @param studList The list of students
	 * @param groupSize The number of students allowed in each group
	 * @return An array of groups of students
	 */
	private static Group[] balanceByGroupSize(ArrayList<Student> studList, int groupSize) {
		int numOfGroups = (int) Math.ceil(studList.size() / ((double) groupSize));
		return balanceByGroupQty(studList, numOfGroups);
	}
	
	/**
	 * Generates a group configuration through balancing by grade
	 * The user specifies the number of groups
	 * @param studList The list of students
	 * @param numOfGroups The number of groups
	 * @return An array of groups of students
	 */
	private static Group[] balanceByGroupQty(ArrayList<Student> studList, int numOfGroups) {
		
		int groupLimit = (int) Math.ceil(studList.size() / ((double) numOfGroups));
		
		// Create an empty matrix within which to store students
		Group[] groups = new Group[numOfGroups];
		for (int i = 0; i < numOfGroups; i++) {
			groups[i] = new Group(groupLimit);
		}
		
		// Calculate average course grade of all students
		double avgGrade = calcAvgGrade(studList);
		// TODO this is printed here for ease of testing
		System.out.println(avgGrade);
		
		// Assign one student to each group
		for (Group group : groups) {
			group.addStudent(studList.remove(0));
		}
		
		while (!studList.isEmpty()) {
			for (Group group : groups) {
				double deviation = Double.MAX_VALUE;
				Student newStud = null;
				for (Student s : studList) {
					double groupAvg = (group.getGradeSum() + s.getGrade()) / (group.getCurrSize() + 1);
					if (Math.abs(groupAvg - avgGrade) < deviation) {
						deviation = Math.abs(groupAvg - avgGrade);
						newStud = s;
					}
				}
				if (newStud != null) {
					group.addStudent(newStud);
					studList.remove(newStud);
				}
			}
		}
		
		return groups;
	}
	
	/**
	 * Calculates the average grade from a list of students
	 * @param studList The list of students
	 * @return The average grade of the students from the list
	 */
	private static double calcAvgGrade(ArrayList<Student> studList) {
		double sum = 0;
		for (Student s : studList) {
			sum += s.getGrade();
		}
		return sum / studList.size();
	}
	
	private static double balancingSuccess(Group[] groups, ArrayList<Student> studList) {
		// calculate std deviation for groups and the worst config of studList
		// std deviation of 0 = 100%, std deviation of that bad config is 0%
		// return a percentage of success
		
		// Creating the worst groups known to man
		int numOfGroups = groups.length;
		int groupLimit = groups[0].getLimit();
		Group[] badGroups = new Group[numOfGroups];
		for (int i = 0; i < numOfGroups; i++) {
			badGroups[i] = new Group(groupLimit);
		}
		ArrayList<Student> decList = sortStuds(studList);
		for (Group group : badGroups) {
			while (!decList.isEmpty() && !group.isFull()) {
				group.addStudent(decList.remove(0));
			}
			if (decList.isEmpty()) {
				break;
			}
		}
		
		return 100 - (100 * calcStdDev(groups, studList) / calcStdDev(badGroups, studList));
	}
	
	private static double calcStdDev(Group[] groups, ArrayList<Student> studList) {
		double stdDev = 0;
        double sum = 0;
        for (Student s : studList) {
            sum += s.getGrade();
        }
        
        double mean = sum / studList.size();
        
        for (Group group : groups) {
            stdDev += Math.pow(((group.getGradeSum() / group.getCurrSize()) - mean), 2);
        }
        
        stdDev = Math.sqrt(stdDev / groups.length);
        
        return stdDev;
	}
	
	 private static Group[] improveBalancing(Group[] groups, ArrayList<Student> studList, int limit) {
	        double ogGroup = balancingSuccess(groups, studList);
	        double newGroup = 0.0;
	        	
	        for (int gIndex = (groups.length - 1); gIndex >= 0; gIndex--) {
	        	//for (int gCounter = 0; gCounter < groups.length; gCounter++) {
	        		int gCounter = 0;
	        		Group tempGroup = new Group(limit);
	        		Group imprvGroup = new Group(limit);
	        		for (int j = 0; j < groups[gCounter].getCurrSize(); j++) {
	        			tempGroup.addStudent(groups[gCounter].getStudent(j));
	        		}
	        		
	        		for (int k = 0; k < groups[gIndex].getCurrSize(); k++) {
	        			imprvGroup.addStudent(groups[gIndex].getStudent(k));
	        		}

	        		if (gIndex != gCounter) {
	        			for (int i = 0; i < imprvGroup.getCurrSize(); i++) {
	        				groups[gIndex].replaceStudent(i, tempGroup.getStudent(i));
	        				groups[gCounter].replaceStudent(i, imprvGroup.getStudent(i));

	        				newGroup = balancingSuccess(groups, studList);
	        				if (newGroup > ogGroup) {
	        					tempGroup.emptyGroup();
	        					for (int j = 0; j < groups[gCounter].getCurrSize(); j++) {
	        						tempGroup.addStudent(groups[gCounter].getStudent(j));
	        					}
	        					
	        					imprvGroup.emptyGroup();
	        					for (int j = 0; j < groups[gIndex].getCurrSize(); j++) {
	        						imprvGroup.addStudent(groups[gIndex].getStudent(j));
	        					}
	        					ogGroup = newGroup;
	        					newGroup = 0;
	        				} else {
	        					groups[gCounter].emptyGroup();
	        					for (int j = 0; j < tempGroup.getCurrSize(); j++) {
	        						groups[gCounter].addStudent(tempGroup.getStudent(j));
	        					}
	        					groups[gIndex].emptyGroup();
	        					for (int j = 0; j < imprvGroup.getCurrSize(); j++) {
	        						groups[gIndex].addStudent(imprvGroup.getStudent(j));
	        					}
	        					newGroup = 0;

	        				}
	        			}
	        		}
	        	}
	        //}
	        return groups;
	    }
	
	// ======================================================================== Aggregation Algorithm
	
	private static Group[] aggregateByGroupSize(ArrayList<Student> studList, int groupSize) {
		int numOfGroups = (int) Math.ceil(studList.size() / ((double) groupSize));
		return aggregateByGroupQty(studList, numOfGroups);
	}
	
	private static Group[] aggregateByGroupQty(ArrayList<Student> studList, int numOfGroups) {
		
		int groupLimit = (int) Math.ceil(studList.size() / ((double) numOfGroups));
		
		// Create an empty matrix within which to store students
		Group[] groups = new Group[numOfGroups];
		for (int i = 0; i < numOfGroups; i++) {
			groups[i] = new Group(groupLimit);
		}
		
		while (!studList.isEmpty()) {
			
			// Find the first empty group
			Group group = null;
			for (int i = 0; i < numOfGroups; i++) {
				if (groups[i].isEmpty()) {
					group = groups[i];
					break;
				}
			}
			
			// Add the first student from studList to the first empty group
			Student s = studList.get(0);
			group.addStudent(s);
			studList.remove(s);
			
			// TODO this creates the possibility for groups of one, but is necessary for now
			if (studList.isEmpty()) {
				break;
			}
			
			// Fill group with students
			studList = sortUnassignedStuds(studList, s);
			while (!group.isFull()) {
				if (studList.isEmpty()) {
					break;
				}
				group.addStudent(studList.remove(0));
			}
		}
		
		return groups;
	}
	
	/**
	 * Sorts a list of students by their attributes. Students who fit best in a group with s are
	 * at a lower index after the sort.
	 * @param studList The list of students to sort
	 * @param s The student whose attributes find best fits for
	 * @return A list of student ordered by how well they would fit in a group with s
	 */
	private static ArrayList<Student> sortUnassignedStuds(ArrayList<Student> studList, Student s) {
		String[] attrs = s.getAttributes();
		
		// For every attribute, from lowest to highest priority...
		for (int a = attrs.length - 1; a >= 0; a--) {
			
			// Search studList from end to beginning. If the current attribute of a student matches that of s, 
			// move that student to the front of studList.
			ArrayList<Student> tmp = new ArrayList<Student>();
			for (int i = studList.size() - 1; i >= 0; i--) {
				if (attrs[a] == studList.get(i).getAttributes()[a]) {
					tmp.add(studList.get(i));
				}
			}
			for (Student stud : studList) {
				if (!tmp.contains(stud)) {
					tmp.add(stud);
				}
			}
			studList = tmp;
		}
		
		return studList;
	}
	
	// ======================================================================== Universal Methods
	
	/**
	 * Randomizes the order of students in a list while destroying the original
	 * @param studList The original list of students
	 * @return The randomized list of students
	 */
	private static ArrayList<Student> shuffleStudList(ArrayList<Student> studList) {
		ArrayList<Student> ret = new ArrayList<Student>();
		int currSize = studList.size();
		while (!studList.isEmpty()) {
			int index = (int) (Math.random() * currSize);
			ret.add(studList.remove(index));
			currSize--;
		}
		return ret;
	}
	
	/**
	 * Sorts the students by grade in ascending order
	 * @param studList The list of students to sort
	 * @return The sorted list of students
	 */
	private static ArrayList<Student> sortStuds(ArrayList<Student> studListOrig) {
		ArrayList<Student> ret = new ArrayList<Student>();
		ArrayList<Student> studList = new ArrayList<Student>();
		for (Student s : studListOrig) {
			studList.add(s);
		}
		while (!studList.isEmpty()) {
			double lowestGrade = Integer.MAX_VALUE;
			Student lowestStudent = null;
			for (Student s : studList) {
				if (s.getGrade() < lowestGrade) {
					lowestGrade = s.getGrade();
					lowestStudent = s;
				}
			}
			ret.add(lowestStudent);
			studList.remove(lowestStudent);
		}
		return ret;
	}
}