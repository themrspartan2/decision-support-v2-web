import java.util.ArrayList;

public class Student {
	
	// ========================================== Properties
	
	private String name;
	private boolean minoStatus;
	private double grade;
	private String[] attributes;
	
	// ========================================== Constructors
	
	public Student(String name) {
		this.name = name;
		this.minoStatus = false;
		this.grade = 0;
	}
	
	public Student(String name, boolean minoStatus) {
		this.name = name;
		this.minoStatus = minoStatus;
		this.grade = 0;
	}
	
	public Student(String name, double grade) {
		this.name = name;
		this.minoStatus = false;
		this.grade = grade;
	}
	
	public Student(String name, String[] attributes) {
		this.name = name;
		this.grade = 0;
		this.minoStatus = false;
		this.attributes = attributes;
	}
	
	public Student(String name, boolean minoStatus, double grade, String[] attributes) {
		this.name = name;
		this.minoStatus = minoStatus;
		this.grade = grade;
		this.attributes = attributes;
	}
	
	// ========================================== Methods
	
	@Override
	public String toString() {
		return this.name;
	}
	
	/**
	 * Returns a string representation of the student with minorityStatus
	 * @return A string representation of the student
	 */
	public String toStringMino() {
		return this.name + ", " + minoStatus;
	}
	
	/**
	 * Returns a string representation of the student with grade
	 * @return A string representation of the student
	 */
	public String toStringGrade() {
		return this.name + ", " + grade;
	}

	// ========================================== Getters & Setters
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isMinoStatus() {
		return minoStatus;
	}

	public void setMinoStatus(boolean minoStatus) {
		this.minoStatus = minoStatus;
	}

	public double getGrade() {
		return grade;
	}

	public void setGrade(double grade) {
		this.grade = grade;
	}
	
	public String[] getAttributes() {
		return attributes;
	}
}
